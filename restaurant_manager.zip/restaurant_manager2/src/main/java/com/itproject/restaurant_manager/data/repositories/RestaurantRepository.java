package com.itproject.restaurant_manager.data.repositories;

import com.itproject.restaurant_manager.data.entities.Restaurant;
import org.springframework.data.repository.CrudRepository;

public interface RestaurantRepository extends BaseRepository {


}
