package com.itproject.restaurant_manager.services;

import com.itproject.restaurant_manager.data.entities.RestaurantTable;
import com.itproject.restaurant_manager.data.entities.TableBooking;
import com.itproject.restaurant_manager.data.repositories.RestaurantRepository;
import com.itproject.restaurant_manager.data.repositories.RestaurantTableRepository;
import com.itproject.restaurant_manager.data.repositories.TableBookingRepository;
import com.itproject.restaurant_manager.data.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public class TableBookingService {

    @Autowired
    RestaurantRepository restaurantRepository;

    @Autowired
    TableBookingRepository tableBookingRepository;

    @Autowired
    RestaurantTableRepository restaurantTableRepository;

    @Autowired
    UserRepository userRepository;



     public List<RestaurantTable> listAvailableTables (Long restaurantID){

         return restaurantTableRepository.findFreeTablesbyRestaurantID(restaurantID);

     }

    public Optional<RestaurantTable> findTablebyId(Long tableID){
         return restaurantTableRepository.findById(tableID);
     }

     void makeaTableBooking(Long restaurantId, Long TableID, Date date, String Time, Long UserId){

         List<RestaurantTable> temp = listAvailableTables(restaurantId);
         if(temp.contains(findTablebyId(TableID))){
             TableBooking tableBooking = new TableBooking(UserId,);

         }







     }

}
