package com.itproject.restaurant_manager.data.repositories;

public interface TableBookingRepository extends BaseRepository {


}
