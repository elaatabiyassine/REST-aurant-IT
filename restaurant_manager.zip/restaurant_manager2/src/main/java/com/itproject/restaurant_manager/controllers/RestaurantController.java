package com.itproject.restaurant_manager.controllers;


import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestaurantController {



}
