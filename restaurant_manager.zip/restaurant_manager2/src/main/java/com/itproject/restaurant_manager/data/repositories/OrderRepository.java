package com.itproject.restaurant_manager.data.repositories;

public interface OrderRepository extends BaseRepository {

}
