package com.itproject.restaurant_manager.data.repositories;

public interface UserRepository extends BaseRepository {

    

}
